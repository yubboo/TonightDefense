赤金炎龙 Boss 音效 CC0 采集清单

这次我把素材按游戏事件整理成 12 组，主清单只选“耳聆网当前页面明确显示 CC0”的声音。
压缩包里不是音频本体，而是每个事件对应的下载页面快捷方式（.url）和用途说明。

为什么不直接塞音频本体：
耳聆网的音频下载由站内下载流程提供；我能核验页面、许可和音频信息，但不会绕过网站的下载机制抓取隐藏文件地址。

推荐操作：
1. 按文件夹顺序打开 .url。
2. 在网页再次确认“CC0 许可协议”。
3. 下载原始音频。
4. 把下载好的原音频一次性发给我。
5. 我可以帮你裁切、降调、叠层、去噪、统一响度，并输出真正的《赤金炎龙_Boss最终音效包》。

最终游戏建议命名：
boss_dragon_appear_roar.wav
boss_dragon_roar_01.wav
boss_dragon_breath_charge.wav
boss_dragon_flame_breath_loop.wav
boss_dragon_fire_burst.wav
boss_dragon_hurt_01.wav
boss_dragon_death.wav
boss_dragon_claw_hit.wav
boss_dragon_takeoff.wav
boss_dragon_ground_slam.wav
boss_dragon_boom.wav
boss_dragon_heavy_land.wav
